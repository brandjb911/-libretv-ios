//
//  LibreTVApp.swift
//  LibreTV
//
//  LibreTV 网站的 iOS 原生容器。
//

import SwiftUI

@main
struct LibreTVApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .preferredColorScheme(.dark)
        }
    }
}
