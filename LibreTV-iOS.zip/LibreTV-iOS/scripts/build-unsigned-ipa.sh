#!/usr/bin/env bash
# 在 macOS（已安装 Xcode 命令行工具）上生成未签名 IPA。
# 用法：bash scripts/build-unsigned-ipa.sh
# 产物：LibreTV-unsigned.ipa（需用 Sideloadly / AltStore 等重签名后才能装到 iPhone）
set -euo pipefail
cd "$(dirname "$0")/.."

SCHEME="LibreTV"
BUILD_DIR="build"

rm -rf "$BUILD_DIR" Payload "$SCHEME-unsigned.ipa"

echo "==> 编译（关闭签名）"
xcodebuild \
  -project "$SCHEME.xcodeproj" \
  -scheme "$SCHEME" \
  -configuration Release \
  -sdk iphoneos \
  -destination "generic/platform=iOS" \
  -derivedDataPath "$BUILD_DIR" \
  CODE_SIGNING_ALLOWED=NO \
  CODE_SIGNING_REQUIRED=NO \
  CODE_SIGN_IDENTITY="" \
  PROVISIONING_PROFILE_SPECIFIER="" \
  build

APP="$BUILD_DIR/Build/Products/Release-iphoneos/$SCHEME.app"
if [ ! -d "$APP" ]; then
  echo "构建产物不存在：$APP" >&2
  exit 1
fi

echo "==> 打包 Payload"
mkdir -p Payload
cp -R "$APP" Payload/
zip -qry "$SCHEME-unsigned.ipa" Payload

echo "==> 完成：$(pwd)/$SCHEME-unsigned.ipa"
