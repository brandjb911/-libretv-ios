//
//  WebViewContainer.swift
//  LibreTV
//

import SwiftUI
import WebKit

struct WebViewContainer: UIViewRepresentable {
    @ObservedObject var model: WebViewModel

    func makeUIView(context: Context) -> WKWebView {
        model.webView
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {
        // 不需要更新：所有导航都由 WebViewModel 驱动
    }
}
