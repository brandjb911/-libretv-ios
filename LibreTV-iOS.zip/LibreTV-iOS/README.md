# LibreTV iOS 版（IPA 工程）

把 LibreTV 网页封成一个可以在 iPhone / iPad 上安装的原生 App：全屏无地址栏、视频可全屏横屏播放、Cookie 登录态持久化、支持自定义站点地址。

> 说明：这份工程在一台 Linux 环境里生成，没有 Xcode / iOS SDK，所以**不能替你在本机直接编出签名 IPA**。工程本身是完整的、可直接编译的，下面给了三条把它变成 `.ipa` 的路径，第一条完全不需要 Mac。

## 目录结构

```
LibreTV-iOS/
├── LibreTV.xcodeproj          # Xcode 工程（可直接打开）
├── LibreTV/
│   ├── LibreTVApp.swift       # App 入口
│   ├── ContentView.swift      # 顶栏 + WebView + 错误页
│   ├── WebViewModel.swift     # WKWebView 封装（媒体/全屏/Cookie/新窗口）
│   ├── WebViewContainer.swift # UIViewRepresentable
│   ├── SettingsView.swift     # 站点地址、清缓存
│   ├── Config.swift           # 默认站点地址（改成你自己的域名）
│   ├── Info.plist             # ATS、方向、深色模式
│   └── Assets.xcassets        # App 图标（含全部尺寸）
├── .github/workflows/build-ipa.yml   # 云端一键出 IPA
├── scripts/build-unsigned-ipa.sh     # Mac 本机出 IPA
├── LibreTV.mobileconfig              # 免签名方案：桌面 Web Clip
└── project.yml                       # XcodeGen 版工程描述（备用）
```

## 方案一：GitHub Actions 云端构建（推荐，无需 Mac）

1. 把 `LibreTV-iOS` 整个目录推到你的 GitHub 仓库（`.github` 目录要一起提交）。
2. 仓库 **Actions** 页 → 选择 `Build unsigned IPA` → **Run workflow**。
3. 跑完在本次运行页面底部下载 `LibreTV-unsigned-ipa` 压缩包，解压得到 `LibreTV-unsigned.ipa`。
4. 这个包是**未签名**的，装之前要用工具重签名（见下节）。

## 方案二：Mac 本机构建

```bash
cd LibreTV-iOS
bash scripts/build-unsigned-ipa.sh      # 产出 LibreTV-unsigned.ipa
```

想直接在 Xcode 里真机调试的话：打开 `LibreTV.xcodeproj` → Target `LibreTV` → Signing & Capabilities → 勾选你的 Apple ID Team，Bundle Identifier 改成唯一的（如 `com.你的名字.libretv`）→ Run。

## 方案三：免签名，30 秒就能用（Web Clip）

`LibreTV.mobileconfig` 是一个 iOS 配置描述文件，作用是在桌面生成一个全屏打开的 LibreTV 图标（本质是 Safari 的 Web Clip），**不需要任何证书和签名**。

- iPhone 用 Safari 打开这个文件（放到自己的网站/网盘直链，或隔空投送传到手机）→ 会提示「已下载描述文件」→ 设置 → 通用 → VPN与设备管理 → 安装。
- 缺点：不是真正的 App，能力受 Safari 限制（例如无法持久后台音频）。

## 装 IPA：重签名

未签名 IPA 直接装会失败，用下面任一工具用你自己的 Apple ID 重签名：

| 工具 | 平台 | 说明 |
| --- | --- | --- |
| Sideloadly | Win / Mac | 数据线连手机，拖入 IPA，填 Apple ID 即可签名安装，最常用 |
| 爱思助手 | Windows | 「IPA 签名」功能，需登录 Apple ID |
| AltStore / SideStore | iOS | 在手机上自签，7 天续签一次 |
| 企业证书 / 开发者账号 | — | 有 99 美元开发者账号可用 Ad Hoc 分发，有效期 1 年 |

免费 Apple ID 签名的 App **7 天后失效**，需要重签；这是苹果的限制，不是工程的问题。

## 改成你自己的 LibreTV 站点

三种方式任选：

1. App 内右上角 ⚙️ → 填你的域名 → 保存并打开（存在本机，重装才丢）。
2. 改 `LibreTV/Config.swift` 里的 `defaultHomeURLString`，重新构建，这样默认就是你自己的站。
3. 你也可以不填，默认指向官方演示站 `https://libretv.is-an.org/`。

自己部署 LibreTV 的方式见上游仓库（支持 Vercel 一键部署 / Docker，仓库地址 `LibreTV` / `LibreTV-Next`）。

## 常用改动

- **改显示名**：`Info.plist` 的 `CFBundleDisplayName`。
- **改包名**：Target 的 `PRODUCT_BUNDLE_IDENTIFIER`（同时会影响签名和覆盖安装）。
- **改图标**：替换 `Assets.xcassets/AppIcon.appiconset` 里的 PNG（保持同名尺寸即可）。
- **允许 http 视频源**：`Info.plist` 里已开 `NSAllowsArbitraryLoads`，这是为了让各种第三方 m3u8 源能直接播；如果你只用自己的 https 站，建议关掉以提升安全性。
- **上架 App Store**：需要去掉 ATS 全放开（否则审核大概率被拒）、补隐私说明，并确保站点内容有合法授权。使用第三方影视聚合源上架基本不可行。

## 免责

本工程只提供网页容器，不内置、不存储、不分发任何视频内容；所有内容来自你配置的站点及其第三方接口。请在当地法律允许的范围内使用，并自行确认所访问内容的授权情况。
