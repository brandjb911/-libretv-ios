//
//  WebViewModel.swift
//  LibreTV
//
//  WKWebView 的封装：媒体自动播放、Cookie 持久化、新窗口复用、前进后退状态等。
//

import WebKit
import UIKit
import Combine

final class WebViewModel: NSObject, ObservableObject {

    let webView: WKWebView

    @Published var canGoBack = false
    @Published var canGoForward = false
    @Published var isLoading = false
    @Published var progress: Double = 0
    @Published var pageTitle = ""
    @Published var errorMessage: String?

    private var observations: [NSKeyValueObservation] = []

    override init() {
        let configuration = WKWebViewConfiguration()
        // 关键：允许内联 / 全屏播放，且不需要用户手势就自动播放（否则点开视频会一直是黑屏）。
        configuration.allowsInlineMediaPlayback = true
        configuration.allowsPictureInPictureMediaPlayback = true
        configuration.mediaTypesRequiringUserActionForPlayback = []
        // 用持久化的数据存储，登录态 / Cookie / localStorage 重启后仍在。
        configuration.websiteDataStore = .default()
        configuration.preferences.javaScriptCanOpenWindowsAutomatically = true
        configuration.defaultWebpagePreferences.allowsContentJavaScript = true
        configuration.defaultWebpagePreferences.preferredContentMode = .mobile
        configuration.applicationNameForUserAgent = AppConfig.userAgentSuffix

        webView = WKWebView(frame: .zero, configuration: configuration)

        super.init()

        webView.navigationDelegate = self
        webView.uiDelegate = self
        webView.allowsBackForwardNavigationGestures = true
        webView.allowsLinkPreview = false
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        webView.isOpaque = false
        webView.backgroundColor = .black
        webView.scrollView.backgroundColor = .black
        if #available(iOS 16.4, *) {
            webView.isInspectable = false
        }

        observations.append(webView.observe(\.canGoBack, options: [.initial, .new]) { [weak self] view, _ in
            let value = view.canGoBack
            DispatchQueue.main.async { self?.canGoBack = value }
        })
        observations.append(webView.observe(\.canGoForward, options: [.initial, .new]) { [weak self] view, _ in
            let value = view.canGoForward
            DispatchQueue.main.async { self?.canGoForward = value }
        })
        observations.append(webView.observe(\.isLoading, options: [.initial, .new]) { [weak self] view, _ in
            let value = view.isLoading
            DispatchQueue.main.async { self?.isLoading = value }
        })
        observations.append(webView.observe(\.estimatedProgress, options: [.initial, .new]) { [weak self] view, _ in
            let value = view.estimatedProgress
            DispatchQueue.main.async {
                self?.progress = value
                if value >= 1.0 { self?.isLoading = false }
            }
        })
        observations.append(webView.observe(\.title, options: [.initial, .new]) { [weak self] view, _ in
            let value = view.title ?? ""
            DispatchQueue.main.async { self?.pageTitle = value }
        })
    }

    deinit {
        observations.forEach { $0.invalidate() }
        observations.removeAll()
    }

    // MARK: - 导航

    func loadHomeIfNeeded() {
        guard webView.url == nil else { return }
        loadHome()
    }

    func loadHome() {
        guard let url = AppConfig.normalizedHomeURL() else {
            errorMessage = "站点地址无法解析，请到「设置」里填写完整网址（含 https://）。"
            return
        }
        errorMessage = nil
        var request = URLRequest(url: url, cachePolicy: .useProtocolCachePolicy, timeoutInterval: 25)
        request.setValue("zh-CN,zh;q=0.9", forHTTPHeaderField: "Accept-Language")
        webView.load(request)
    }

    func reload() {
        errorMessage = nil
        if webView.url == nil {
            loadHome()
        } else {
            webView.reload()
        }
    }

    func goBack() {
        guard webView.canGoBack else { return }
        webView.goBack()
    }

    func goForward() {
        guard webView.canGoForward else { return }
        webView.goForward()
    }

    /// 清除缓存、Cookie 与本地存储后重新加载首页。
    func clearWebsiteData() {
        URLCache.shared.removeAllCachedResponses()
        let dataStore = WKWebsiteDataStore.default()
        let types = WKWebsiteDataStore.allWebsiteDataTypes()
        dataStore.removeData(ofTypes: types, modifiedSince: .distantPast) { [weak self] in
            DispatchQueue.main.async { self?.loadHome() }
        }
    }
}

// MARK: - WKNavigationDelegate

extension WebViewModel: WKNavigationDelegate {

    private static let allowedSchemes: Set<String> = [
        "http", "https", "file", "about", "blob", "data", "javascript"
    ]

    func webView(_ webView: WKWebView,
                 decidePolicyFor navigationAction: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = navigationAction.request.url,
              let scheme = url.scheme?.lowercased(),
              !scheme.isEmpty else {
            decisionHandler(.allow)
            return
        }

        if Self.allowedSchemes.contains(scheme) {
            decisionHandler(.allow)
            return
        }

        // tel:、mailto:、itms-apps:、weixin:// 等交给系统处理
        decisionHandler(.cancel)
        DispatchQueue.main.async {
            if UIApplication.shared.canOpenURL(url) {
                UIApplication.shared.open(url, options: [:], completionHandler: nil)
            }
        }
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        errorMessage = nil
    }

    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        report(error, url: webView.url)
    }

    func webView(_ webView: WKWebView,
                 didFailProvisionalNavigation navigation: WKNavigation!,
                 withError error: Error) {
        report(error, url: webView.url)
    }

    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
        // 系统内存回收导致渲染进程被杀，自动重载
        webView.reload()
    }

    private func report(_ error: Error, url: URL?) {
        let nsError = error as NSError
        // 用户主动取消导航不算错误
        if nsError.domain == NSURLErrorDomain && nsError.code == NSURLErrorCancelled { return }
        let host = url?.host ?? "站点"
        let text = "无法连接到 \(host)\n\(nsError.localizedDescription)"
        DispatchQueue.main.async {
            self.errorMessage = text
            self.isLoading = false
        }
    }
}

// MARK: - WKUIDelegate

extension WebViewModel: WKUIDelegate {

    /// target="_blank" / window.open 的页面在当前 WebView 里打开，而不是被丢弃。
    func webView(_ webView: WKWebView,
                 createWebViewWith configuration: WKWebViewConfiguration,
                 for navigationAction: WKNavigationAction,
                 windowFeatures: WKWindowFeatures) -> WKWebView? {
        guard navigationAction.targetFrame == nil,
              let url = navigationAction.request.url else { return nil }
        let scheme = url.scheme?.lowercased() ?? ""
        if ["http", "https", "about", "blob", "file", "data"].contains(scheme) {
            webView.load(navigationAction.request)
        } else {
            DispatchQueue.main.async {
                UIApplication.shared.open(url, options: [:], completionHandler: nil)
            }
        }
        return nil
    }

    func webView(_ webView: WKWebView,
                 runJavaScriptAlertPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo,
                 completionHandler: @escaping () -> Void) {
        guard let presenter = UIApplication.topmostViewController() else {
            completionHandler()
            return
        }
        let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "好", style: .default) { _ in completionHandler() })
        presenter.present(alert, animated: true)
    }

    func webView(_ webView: WKWebView,
                 runJavaScriptConfirmPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo,
                 completionHandler: @escaping (Bool) -> Void) {
        guard let presenter = UIApplication.topmostViewController() else {
            completionHandler(false)
            return
        }
        let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "取消", style: .cancel) { _ in completionHandler(false) })
        alert.addAction(UIAlertAction(title: "确定", style: .default) { _ in completionHandler(true) })
        presenter.present(alert, animated: true)
    }

    func webView(_ webView: WKWebView,
                 runJavaScriptTextInputPanelWithPrompt prompt: String,
                 defaultText: String?,
                 initiatedByFrame frame: WKFrameInfo,
                 completionHandler: @escaping (String?) -> Void) {
        guard let presenter = UIApplication.topmostViewController() else {
            completionHandler(nil)
            return
        }
        let alert = UIAlertController(title: nil, message: prompt, preferredStyle: .alert)
        alert.addTextField { field in
            field.text = defaultText
        }
        alert.addAction(UIAlertAction(title: "取消", style: .cancel) { _ in completionHandler(nil) })
        alert.addAction(UIAlertAction(title: "确定", style: .default) { _ in
            completionHandler(alert.textFields?.first?.text ?? "")
        })
        presenter.present(alert, animated: true)
    }
}

// MARK: - UIApplication 扩展

extension UIApplication {

    static func topmostViewController() -> UIViewController? {
        let scenes = UIApplication.shared.connectedScenes
        let windowScene = scenes.first { $0.activationState == .foregroundActive } as? UIWindowScene
        let keyWindow = windowScene?.windows.first { $0.isKeyWindow } ?? windowScene?.windows.first
        var current = keyWindow?.rootViewController
        while let presented = current?.presentedViewController {
            current = presented
        }
        if let nav = current as? UINavigationController {
            return nav.visibleViewController ?? nav
        }
        if let tab = current as? UITabBarController {
            return tab.selectedViewController ?? tab
        }
        return current
    }
}
