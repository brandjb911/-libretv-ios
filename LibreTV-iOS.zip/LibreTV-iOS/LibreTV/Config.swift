//
//  Config.swift
//  LibreTV
//
//  站点地址等基础配置。改这里的默认值即可让 App 指向你自己的 LibreTV 实例。
//

import Foundation

enum AppConfig {

    /// 官方演示站。部署了自己的实例后，把这里换成你的域名（例如 "https://tv.example.com/"）。
    static let defaultHomeURLString = "https://libretv.is-an.org/"

    private static let homeURLKey = "libretv.homeURL"

    /// 当前使用的站点地址（可在 App 内「设置」里修改，保存在 UserDefaults）。
    static var homeURLString: String {
        get {
            let value = UserDefaults.standard.string(forKey: homeURLKey)?
                .trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
            return value.isEmpty ? defaultHomeURLString : value
        }
        set {
            UserDefaults.standard.set(newValue.trimmingCharacters(in: .whitespacesAndNewlines), forKey: homeURLKey)
        }
    }

    /// 归一化后的站点 URL：缺少 scheme 时自动补 https://
    static func normalizedHomeURL(_ raw: String = AppConfig.homeURLString) -> URL? {
        var text = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else { return nil }
        if !text.contains("://") {
            text = "https://" + text
        }
        return URL(string: text)
    }

    /// 附加在默认 UA 后面的标识，部分站点会据此走移动端布局。
    static let userAgentSuffix = " LibreTViOSApp/1.0"

    static func resetHomeURL() {
        UserDefaults.standard.removeObject(forKey: homeURLKey)
    }
}
