//
//  ContentView.swift
//  LibreTV
//

import SwiftUI

struct ContentView: View {

    @StateObject private var model = WebViewModel()
    @State private var showSettings = false

    var body: some View {
        VStack(spacing: 0) {
            topBar

            ZStack(alignment: .top) {
                WebViewContainer(model: model)
                    .ignoresSafeArea(edges: .bottom)

                if model.isLoading {
                    ProgressView(value: max(0.02, model.progress))
                        .progressViewStyle(.linear)
                        .tint(Color(red: 0.15, green: 0.95, blue: 0.65))
                        .frame(height: 2)
                }

                if let message = model.errorMessage {
                    errorView(message: message)
                }
            }
        }
        .background(Color.black)
        .onAppear { model.loadHomeIfNeeded() }
        .sheet(isPresented: $showSettings) {
            SettingsView(model: model)
        }
    }

    // MARK: - 顶部条

    private var topBar: some View {
        HStack(spacing: 16) {
            iconButton("chevron.left", enabled: model.canGoBack) { model.goBack() }
            iconButton("chevron.right", enabled: model.canGoForward) { model.goForward() }

            Spacer(minLength: 6)

            Text(model.pageTitle.isEmpty ? "LibreTV" : model.pageTitle)
                .font(.system(size: 13, weight: .semibold))
                .foregroundColor(.white.opacity(0.7))
                .lineLimit(1)
                .truncationMode(.middle)

            Spacer(minLength: 6)

            iconButton("arrow.clockwise") { model.reload() }
            iconButton("house") { model.loadHome() }
            iconButton("gearshape") { showSettings = true }
        }
        .padding(.horizontal, 14)
        .frame(height: 44)
        .background(Color(red: 0.04, green: 0.05, blue: 0.09))
    }

    private func iconButton(_ systemName: String,
                            enabled: Bool = true,
                            action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: systemName)
                .font(.system(size: 17, weight: .semibold))
                .frame(width: 30, height: 30)
                .foregroundColor(enabled ? Color(red: 0.15, green: 0.95, blue: 0.65) : Color.white.opacity(0.22))
        }
        .buttonStyle(.plain)
        .disabled(!enabled)
    }

    // MARK: - 错误提示

    private func errorView(message: String) -> some View {
        VStack(spacing: 14) {
            Image(systemName: "wifi.exclamationmark")
                .font(.system(size: 36, weight: .regular))
                .foregroundColor(Color(red: 0.15, green: 0.95, blue: 0.65))

            Text("页面加载失败")
                .font(.system(size: 17, weight: .semibold))
                .foregroundColor(.white)

            Text(message)
                .font(.system(size: 13))
                .foregroundColor(.white.opacity(0.6))
                .multilineTextAlignment(.center)
                .padding(.horizontal, 28)

            Button {
                model.reload()
            } label: {
                Text("重试")
                    .font(.system(size: 15, weight: .semibold))
                    .padding(.horizontal, 26)
                    .padding(.vertical, 9)
                    .background(Color(red: 0.15, green: 0.95, blue: 0.65))
                    .foregroundColor(.black)
                    .clipShape(Capsule())
            }
            .buttonStyle(.plain)

            Button("检查站点地址") { showSettings = true }
                .font(.system(size: 13))
                .foregroundColor(.white.opacity(0.55))
                .buttonStyle(.plain)
        }
        .padding(.vertical, 26)
        .padding(.horizontal, 20)
        .frame(maxWidth: .infinity)
        .background(Color(red: 0.07, green: 0.09, blue: 0.14))
        .transition(.opacity)
    }
}

#Preview {
    ContentView()
}
