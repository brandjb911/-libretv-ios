//
//  SettingsView.swift
//  LibreTV
//

import SwiftUI

struct SettingsView: View {

    @ObservedObject var model: WebViewModel
    @Environment(\.dismiss) private var dismiss

    @State private var urlText: String = AppConfig.homeURLString
    @State private var errorText: String?

    var body: some View {
        NavigationView {
            Form {
                Section {
                    TextField("https://your-domain.com/", text: $urlText)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled(true)
                        .keyboardType(.URL)
                } header: {
                    Text("LibreTV 站点地址")
                } footer: {
                    Text("填官方演示站，或你自己部署的 LibreTV 实例地址（Vercel / Docker / 自建服务器均可）。")
                }

                Section {
                    Button("保存并打开") {
                        save(reload: true)
                    }
                    Button("恢复官方演示站") {
                        urlText = AppConfig.defaultHomeURLString
                    }
                    Button("清除缓存与登录态", role: .destructive) {
                        model.clearWebsiteData()
                        dismiss()
                    }
                }

                Section {
                    HStack {
                        Text("当前站点")
                        Spacer()
                        Text(AppConfig.homeURLString)
                            .foregroundColor(.secondary)
                            .lineLimit(1)
                            .truncationMode(.middle)
                    }
                    .font(.system(size: 14))
                } footer: {
                    Text("本应用只是 LibreTV 网页的 iOS 容器，不内置、不存储任何视频内容；所有内容由你填写的站点及其第三方接口提供。")
                }
            }
            .navigationTitle("设置")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("完成") { dismiss() }
                }
            }
            .alert("地址格式不正确", isPresented: Binding(
                get: { errorText != nil },
                set: { if !$0 { errorText = nil } }
            )) {
                Button("好", role: .cancel) { errorText = nil }
            } message: {
                Text(errorText ?? "")
            }
        }
        .navigationViewStyle(.stack)
    }

    private func save(reload: Bool) {
        var text = urlText.trimmingCharacters(in: .whitespacesAndNewlines)
        if text.isEmpty { text = AppConfig.defaultHomeURLString }
        guard AppConfig.normalizedHomeURL(text) != nil else {
            errorText = "请填写完整网址，例如 https://libretv.is-an.org/"
            return
        }
        AppConfig.homeURLString = text
        urlText = text
        if reload {
            model.loadHome()
            dismiss()
        }
    }
}
